# Blog do código
> Um blog simples em Node.js