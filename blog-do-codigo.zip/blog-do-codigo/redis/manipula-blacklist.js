const blacklist = require('./blacklist');

const { promisify } = require('util');
const existsAsync = promisify(blacklist.exists).bind(blacklist); //Função que vai devolver uma promise
const setAsync = promisify(blacklist.set).bind(blacklist);

const jwt = require('jsonwebtoken');
const { createHash } = require('crypto');

function geraTokenHash(token){
    return createHash('sha256') //Cria uma criptografia hash do tipo SHA256 
        .update(token) //Esse hash substitui o token usando update(atualizando o token pelo hash)
        .digest('hex'); //digest - usado para escolher a codificação usada desse has
}

module.exports = {
    adiciona: async token => {
        const dataExpiracao = jwt.decode(token).exp;
        const tokenHash = geraTokenHash(token);
        await setAsync(tokenHash, ''); 
        blacklist.expireat(tokenHash, dataExpiracao);
    },

    contemToken: async token => {
        const tokenHash = geraTokenHash(token);
        const resultado = await existsAsync(tokenHash); //Resultado da função será 1 se o token estiver na base e 0 se não.
        return resultado === 1;
    }
}

//blacklist.set - recebe uma chave e um valor, e adicionamos essa dupla em nossa base no "redis".

//jwt.decode(token).exp;
//jwt - usa um módulo para json web token
//.decode() - decodifica o token
//.exp - pega em vez do payload o tempo de expiração do token