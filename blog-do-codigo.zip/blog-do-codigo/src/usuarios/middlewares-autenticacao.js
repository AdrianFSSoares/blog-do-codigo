const passport = require('passport');

module.exports = {
    local:  (req, res, next) => {
        passport.authenticate(
            'local',
            { session: false }, 
            (erro, usuario, info) => {
                if (erro && erro.name === 'InvalidArgumentError') {
                    return res.status(401).json({ erro: erro.message });
                }

                if (erro) {
                    return res.status(500).json({ erro: erro.message });
                }

                if (!usuario) {
                    return res.status(401).json();
                }

                req.user = usuario;
                return next();
            }
        )(req, res, next);
    },

    bearer:  (req, res, next) => {
        passport.authenticate(
            'bearer',
            { session: false }, 
            (erro, usuario, info) => {
                if (erro && erro.name === 'JsonWebTokenError') {
                    return res.status(401).json({ erro: erro.message });
                }

                if (erro && erro.name === 'TokenExpiredError'){
                    return res
                        .status(401)
                        .json({ erro: erro.message, expiradoEm: erro.expiredAt });
                }

                if (erro) {
                    return res.status(500).json({ erro: erro.message });
                }

                if (!usuario) {
                    return res.status(401).json();
                }

                //Para recuperar o roken no controlador agente insere ele na requisição
                req.token = info.token; //o token da requisição é o token dentro das informações extras
                req.user = usuario;
                return next();
            }
        )(req, res, next);
    }
};

//passport.authenticate() recebe 2 ou mais argumentos. 
//O primeiro é a estratégia que vamos usar nessa autenticação. Ex: 'local' ou 'bearer'
//O segundo argumento é relacionado com o fato de se será usado 
//O terceiro argumento é uma função CALLBACK customizada 
//Função CALLBACK argumentos: (erro que obteve da estratégia, o usuário que você obteve, informações adicionais)
