const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy; //Importa a classe da estratégia passport-local
const BearerStrategy = require('passport-http-bearer').Strategy; //Importa a classe da estratégia passport-htt-beaer

const Usuario = require('./usuarios-modelo');

const { InvalidArgumentError } = require('../erros');

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const blacklist = require('../../redis/manipula-blacklist');

function verificaUsuario(usuario){
    if (!usuario){
        throw new InvalidArgumentError('Não existe usuário com esse e-mail');
    }
}

async function verificaTokenBlacklist(token){
    const tokenNaBlacklist = await blacklist.contemToken(token);
    if(tokenNaBlacklist){
        throw new jwt.JsonWebTokenError('Token inválido por logout!');
    }
}

async function verificaSenha(senha, senhaHash){
    const senhaValida = await bcrypt.compare(senha, senhaHash); //O bcrypt.compare retorna uma promise !-! Use então async e await
    if (!senhaValida){
        throw new InvalidArgumentError('E-mail ou senha inválidos');
    }
}

passport.use(
    new LocalStrategy({ //Sistema de Login
        usernameField: 'email',
        passwordField: 'senha',
        session: false //Não usará sessões
    }, async (email, senha, done) => { //Se as credencias do usuário entiverem válidas essa função devolve este usuário para a função CALLBACK
        try{
            const usuario = await Usuario.buscaPorEmail(email);
            verificaUsuario(usuario); //Função usada para verificar se o usuário existe ou não
            await verificaSenha(senha, usuario.senhaHash); //Função usada para verificar se a senha que enviamos é a mesma que a senhaHash e se ela existe ou não
        
            done(null, usuario); //null significa que não houve erro e usuario para  mostar que esse cliente que fez a requisição está autenticado
        } catch(erro) {
            done(erro);
        }
    })
);

passport.use(
    new BearerStrategy(
        async (token, done) => { //pega o token criado para verificar se ele está valido e recuperar o PAYLOAD a partir dele
            try{
                await verificaTokenBlacklist(token);
                const payload = jwt.verify(token, process.env.CHAVE_JWT); //Verifica se o token é válido usando a chave secreta e se sim retorna o PAYLOAD do token
                const usuario = await Usuario.buscaPorId(payload.id); //REupera o usuário buscando o registro de usuário com o mesmo id que foi devolvido no PAYLOAD
    
                done(null, usuario, { token: token });
            } catch (erro){
                done(erro);
            }
        }
    )
)

// LocalStrategy(Objeto Opicional com algumas opções de modificação, função de verificação da estratégia local)
//done(1,2,3) a função done é a função CALLBACK do passport autentication
//1- argumento de erro, se tiver um (erro) e se não (null)
//2- argumrnto que armazena o que será enviado de volta
//3- um atributo token que vai receber o token da estratégia
